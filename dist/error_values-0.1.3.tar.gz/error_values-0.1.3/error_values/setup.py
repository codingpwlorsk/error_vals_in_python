from setuptools import setup,find_packages



setup(
    name="error_values",
    version="0.1.3",
    packages=find_packages(),
    )